package com.example.projemobil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.os.Build;
import android.media.RingtoneManager;
import android.net.Uri;
import android.media.Ringtone;
import android.content.res.Resources;
import android.media.MediaPlayer;

public class TatbikatAlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Alarm tetiklendiğinde yapılacak işlemler burada tanımlanır
        showNotification(context, "Deprem Tatbikatı", "Tatbikat yapma zamanı!");
        playAlarmSound(context);
    }

    private void showNotification(Context context, String title, String message) {
        // Bildirim gösterme işlemleri burada yapılır
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Bildirim kanalı oluşturma
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("tatbikat_channel", "Tatbikat Alarmı", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        // Bildirim oluşturma
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "tatbikat_channel")
                .setSmallIcon(R.mipmap.notification_icon)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        // Bildirimi gösterme
        notificationManager.notify(1, builder.build());
    }

    private void playAlarmSound(Context context) {
        MediaPlayer mediaPlayer = MediaPlayer.create(context, R.raw.alarm); // Alarm sesinin adını buraya ekleyin
        if (mediaPlayer != null) {
            mediaPlayer.start();
        }
    }
}
