package com.example.projemobil;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BagisActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BankaHesaplariAdapter adapter;
    private List<String> bankaHesaplari;
    private Button btnGarantiUygulama;
    private Button btnZiraatUygulama;
    private Button btnIsCepUygulama;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bagis);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        bankaHesaplari = new ArrayList<>();
        bankaHesaplari.add("TR12 0000 0000 0000 0000 0000");
        bankaHesaplari.add("TR34 1111 1111 1111 1111 1111");
        bankaHesaplari.add("TR56 2222 2222 2222 2222 2222");
        bankaHesaplari.add("TR78 3333 3333 3333 3333 3333");
        bankaHesaplari.add("TR90 4444 4444 4444 4444 4444");
        bankaHesaplari.add("TR45 5555 5555 5555 5555 5555");

        adapter = new BankaHesaplariAdapter(bankaHesaplari);
        recyclerView.setAdapter(adapter);

        btnGarantiUygulama = findViewById(R.id.btnGarantiUygulama);
        btnGarantiUygulama.setOnClickListener(v -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.garanti.cepsubesi");
            if (intent != null) {
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Garanti Bankası uygulaması yüklü değil.", Toast.LENGTH_SHORT).show();
            }
        });

        btnZiraatUygulama = findViewById(R.id.btnZiraatUygulama);
        btnZiraatUygulama.setOnClickListener(v -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.ziraat.ziraatmobil");
            if (intent != null) {
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Ziraat Bankası uygulaması yüklü değil.", Toast.LENGTH_SHORT).show();
            }
        });

        btnIsCepUygulama = findViewById(R.id.btnIsCepUygulama);
        btnIsCepUygulama.setOnClickListener(v -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.pozitron.iscep");
            if (intent != null) {
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "İş Bankası uygulaması yüklü değil.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private class BankaHesaplariAdapter extends RecyclerView.Adapter<BankaHesaplariAdapter.ViewHolder> {

        private List<String> bankaHesaplari;

        public BankaHesaplariAdapter(List<String> bankaHesaplari) {
            this.bankaHesaplari = bankaHesaplari;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_banka_hesabi, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String hesap = bankaHesaplari.get(position);
            holder.tvBankaHesap.setText(hesap);

            holder.btnKopyala.setOnClickListener(v -> {
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clipData = ClipData.newPlainText("Hesap Bilgisi", hesap);
                clipboardManager.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(), "Hesap bilgisi kopyalandı", Toast.LENGTH_SHORT).show();
            });

            holder.btnGarantiUygulama.setVisibility(View.GONE);
        }

        @Override
        public int getItemCount() {
            return bankaHesaplari.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvBankaHesap;
            Button btnKopyala;
            Button btnGarantiUygulama;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvBankaHesap = itemView.findViewById(R.id.tvBankaHesap);
                btnKopyala = itemView.findViewById(R.id.btnKopyala);
                btnGarantiUygulama = itemView.findViewById(R.id.btnGarantiUygulama);
                btnGarantiUygulama.setVisibility(View.GONE);
            }
        }
    }
}
