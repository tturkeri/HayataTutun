package com.example.projemobil;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import android.content.Context;
import android.app.PendingIntent;
import java.util.Calendar;

public class DepremTatbikatAlarmiActivity extends AppCompatActivity {

    private TimePicker timePicker;
    private DatePicker datePicker;
    private Button createTatbikatButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deprem_tatbikat_alarmi);

        timePicker = findViewById(R.id.timePicker);
        datePicker = findViewById(R.id.datePicker);
        createTatbikatButton = findViewById(R.id.createTatbikatButton);

        createTatbikatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour, minute, year, month, day;

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    hour = timePicker.getHour();
                    minute = timePicker.getMinute();
                } else {
                    hour = timePicker.getCurrentHour();
                    minute = timePicker.getCurrentMinute();
                }

                year = datePicker.getYear();
                month = datePicker.getMonth();
                day = datePicker.getDayOfMonth();

                // Tatbikat oluşturma işlemleri burada gerçekleştirilecek
                createTatbikat(hour, minute, year, month, day);
            }
        });
    }

    private void createTatbikat(int hour, int minute, int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);

        // AlarmManager ile alarmı ayarla
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, TatbikatAlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0);

        // Alarm tetikleme zamanını belirle
        if (alarmManager != null) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        }

        Toast.makeText(this, "Deprem tatbikatı alarmı oluşturuldu!", Toast.LENGTH_SHORT).show();
    }

}
