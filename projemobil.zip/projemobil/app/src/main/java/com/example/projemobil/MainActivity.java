package com.example.projemobil;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {

    private static final String DB_URL = "jdbc:postgresql://deprem.ccd6u6noakod.us-east-1.rds.amazonaws.com:5432/deprem";
    private static final String DB_USERNAME = "baysal";
    private static final String DB_PASSWORD = "Baysal01.";

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private Connection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                new CheckCredentialsTask().execute(username, password);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        // Veritabanı bağlantısını aç
        new ConnectToDatabaseTask().execute();
    }

    private class CheckCredentialsTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... credentials) {
            // Kullanıcı adı ve şifre doğrulama işlemi
            if (connection != null) {
                try {
                    String query = "SELECT * FROM uyeler WHERE kullanici_adi = ? AND sifre = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, credentials[0]);
                    statement.setString(2, credentials[1]);
                    ResultSet resultSet = statement.executeQuery();
                    return resultSet.next();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                // Başarılı giriş işlemi
                Toast.makeText(MainActivity.this, "Giriş Başarılı!", Toast.LENGTH_SHORT).show();

                // Kullanıcının id'sini al
                new GetUserIdTask().execute(usernameEditText.getText().toString());
            } else {
                // Başarısız giriş işlemi
                Toast.makeText(MainActivity.this, "Giriş Başarısız!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class GetUserIdTask extends AsyncTask<String, Void, Integer> {
        @Override
        protected Integer doInBackground(String... usernames) {
            if (connection != null) {
                try {
                    String query = "SELECT id FROM uyeler WHERE kullanici_adi = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, usernames[0]);
                    ResultSet resultSet = statement.executeQuery();
                    if (resultSet.next()) {
                        return resultSet.getInt("id");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Integer userId) {
            if (userId != null) {
                // Kullanıcı id'sini alarak AnasayfaActivity'e geçiş yap
                Intent intent = new Intent(MainActivity.this, AnasayfaActivity.class);
                intent.putExtra("user_id", userId);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Kullanıcı id'si alınamadı!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class ConnectToDatabaseTask extends AsyncTask<Void, Void, Exception> {
        @Override
        protected Exception doInBackground(Void... voids) {
            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            } catch (ClassNotFoundException | SQLException e) {
                return e;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Exception exception) {
            if (exception != null) {
                if (exception instanceof ClassNotFoundException) {
                    Toast.makeText(MainActivity.this, "PostgreSQL sürücüsü bulunamadı!", Toast.LENGTH_SHORT).show();
                } else if (exception instanceof SQLException) {
                    Toast.makeText(MainActivity.this, "Veritabanına bağlanırken hata oluştu!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Veritabanına başarıyla bağlanıldı!", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
