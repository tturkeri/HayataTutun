package com.example.projemobil;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DepremCantasiHazirlamaActivity extends AppCompatActivity {

    private static final String DB_URL = "jdbc:postgresql://deprem.ccd6u6noakod.us-east-1.rds.amazonaws.com:5432/deprem";
    private static final String DB_USERNAME = "baysal";
    private static final String DB_PASSWORD = "Baysal01.";

    private CheckBox elFeneriCheckBox;
    private CheckBox pilCheckBox;
    private CheckBox suCheckBox;
    private CheckBox konserveCheckBox;
    private CheckBox biskuviCheckBox;
    private CheckBox dudukCheckBox;
    private CheckBox paraCheckBox;
    private CheckBox radyoCheckBox;
    private CheckBox telsizCheckBox;
    private CheckBox termalBattaniyeCheckBox;
    private Button kaydetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deprem_cantasi_hazirlama);

        elFeneriCheckBox = findViewById(R.id.elFeneriCheckBox);
        pilCheckBox = findViewById(R.id.pilCheckBox);
        suCheckBox = findViewById(R.id.suCheckBox);
        konserveCheckBox = findViewById(R.id.konserveCheckBox);
        biskuviCheckBox = findViewById(R.id.biskuviCheckBox);
        dudukCheckBox = findViewById(R.id.dudukCheckBox);
        paraCheckBox = findViewById(R.id.paraCheckBox);
        radyoCheckBox = findViewById(R.id.radyoCheckBox);
        telsizCheckBox = findViewById(R.id.telsizCheckBox);
        termalBattaniyeCheckBox = findViewById(R.id.termalBattaniyeCheckBox);
        kaydetButton = findViewById(R.id.kaydetButton);

        kaydetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kaydetme işleminden önce kullanıcı kimliğini al
                int userId = getIntent().getIntExtra("user_id", -1);
                if (userId != -1) {
                    String seciliUrunler = getSeciliUrunler();
                    if (!seciliUrunler.isEmpty()) {
                        checkRecordExists(userId, seciliUrunler);
                    } else {
                        Toast.makeText(DepremCantasiHazirlamaActivity.this, "En az bir ürün seçmelisiniz!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(DepremCantasiHazirlamaActivity.this, "Kullanıcı kimliği alınamadı!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void checkRecordExists(int userId, String urunler) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                    String query = "SELECT * FROM deprem_cantasi_urunleri WHERE uye_id = ?";
                    PreparedStatement preparedStatement = conn.prepareStatement(query);
                    preparedStatement.setInt(1, userId);
                    ResultSet resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        guncelle(userId, urunler);
                    } else {
                        ekle(userId, urunler);
                    }
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Kayıt kontrolü sırasında bir hata oluştu!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        thread.start();
    }

    private void ekle(int userId, String urunler) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                    String query = "INSERT INTO deprem_cantasi_urunleri (urun_adi, secili, uye_id) VALUES (?, ?, ?)";
                    PreparedStatement preparedStatement = conn.prepareStatement(query);
                    preparedStatement.setString(1, urunler);
                    preparedStatement.setBoolean(2, true);
                    preparedStatement.setInt(3, userId);
                    int affectedRows = preparedStatement.executeUpdate();
                    conn.close();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (affectedRows > 0) {
                                kontrolEt(urunler);
                            } else {
                                Toast.makeText(getApplicationContext(), "Kaydetme işlemi başarısız oldu!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (SQLException e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Kaydetme işlemi sırasında bir hata oluştu!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        thread.start();
    }

    private void guncelle(int userId, String urunler) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                    String query = "UPDATE deprem_cantasi_urunleri SET urun_adi = ?, secili = ? WHERE uye_id = ?";
                    PreparedStatement preparedStatement = conn.prepareStatement(query);
                    preparedStatement.setString(1, urunler);
                    preparedStatement.setBoolean(2, true);
                    preparedStatement.setInt(3, userId);
                    int affectedRows = preparedStatement.executeUpdate();
                    conn.close();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (affectedRows > 0) {
                                kontrolEt(urunler);
                            } else {
                                Toast.makeText(getApplicationContext(), "Güncelleme işlemi başarısız oldu!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } catch (SQLException e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Güncelleme işlemi sırasında bir hata oluştu!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        thread.start();
    }

    private void kontrolEt(String urunler) {
        if (urunler.equals("El Feneri, Pil, Su, Konserve, Bisküvi, Düdük, Para, Radyo, Telsiz, Termal Battaniye")) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(), "Çantanız hazır!", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast toast = Toast.makeText(getApplicationContext(), "Eksikler var!", Toast.LENGTH_SHORT);
                    View view = toast.getView();
                    view.setBackgroundColor(Color.RED);
                    toast.show();
                }
            });
        }
    }

    private String getSeciliUrunler() {
        StringBuilder seciliUrunler = new StringBuilder();

        if (elFeneriCheckBox.isChecked())
            seciliUrunler.append("El Feneri, ");
        if (pilCheckBox.isChecked())
            seciliUrunler.append("Pil, ");
        if (suCheckBox.isChecked())
            seciliUrunler.append("Su, ");
        if (konserveCheckBox.isChecked())
            seciliUrunler.append("Konserve, ");
        if (biskuviCheckBox.isChecked())
            seciliUrunler.append("Bisküvi, ");
        if (dudukCheckBox.isChecked())
            seciliUrunler.append("Düdük, ");
        if (paraCheckBox.isChecked())
            seciliUrunler.append("Para, ");
        if (radyoCheckBox.isChecked())
            seciliUrunler.append("Radyo, ");
        if (telsizCheckBox.isChecked())
            seciliUrunler.append("Telsiz, ");
        if (termalBattaniyeCheckBox.isChecked())
            seciliUrunler.append("Termal Battaniye");

        return seciliUrunler.toString();
    }
}
