package com.example.projemobil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class PostgreSQLDatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "deprem.db";
    private static final String TABLE_CANTALAR = "cantalar";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_KULLANICI_ID = "kullanici_id";
    private static final String COLUMN_CANTA_ICERIGI = "canta_icerigi";
    private static final String COLUMN_IS_CHECKED = "is_checked";

    public PostgreSQLDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_CANTALAR +
                "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_KULLANICI_ID + " INTEGER," +
                COLUMN_CANTA_ICERIGI + " TEXT," +
                COLUMN_IS_CHECKED + " INTEGER," +
                "FOREIGN KEY (" + COLUMN_KULLANICI_ID + ") REFERENCES uyeler (id)" +
                ")";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String dropTableQuery = "DROP TABLE IF EXISTS " + TABLE_CANTALAR;
        db.execSQL(dropTableQuery);
        onCreate(db);
    }

    public void kaydet(String icerik) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CANTA_ICERIGI, icerik);
        values.put(COLUMN_IS_CHECKED, 0);
        db.insert(TABLE_CANTALAR, null, values);
        db.close();
    }

    public void duzenle(int id, String yeniIcerik) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CANTA_ICERIGI, yeniIcerik);
        db.update(TABLE_CANTALAR, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public List<String> getAllCantalar() {
        List<String> cantaIcerigiList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CANTALAR, null);
        if (cursor.moveToFirst()) {
            do {
                String cantaIcerigi = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CANTA_ICERIGI));
                cantaIcerigiList.add(cantaIcerigi);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return cantaIcerigiList;
    }

    public void updateCheckedStatus(int id, String icerik, boolean isChecked) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IS_CHECKED, isChecked ? 1 : 0);
        db.update(TABLE_CANTALAR, values, COLUMN_ID + "=? AND " + COLUMN_CANTA_ICERIGI + "=?", new String[]{String.valueOf(id), icerik});
        db.close();
    }

    public boolean isChecked(int position, String icerik) {
        SQLiteDatabase db = getReadableDatabase();
        String[] columns = {COLUMN_IS_CHECKED};
        String selection = COLUMN_ID + " = ? AND " + COLUMN_CANTA_ICERIGI + " = ?";
        String[] selectionArgs = {String.valueOf(position), icerik};
        Cursor cursor = db.query(TABLE_CANTALAR, columns, selection, selectionArgs, null, null, null);
        boolean isChecked = false;
        if (cursor.moveToFirst()) {
            int checkedValue = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_CHECKED));
            isChecked = (checkedValue == 1);
        }
        cursor.close();
        db.close();
        return isChecked;
    }
}
