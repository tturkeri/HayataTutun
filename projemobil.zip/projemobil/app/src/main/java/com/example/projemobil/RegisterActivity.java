package com.example.projemobil;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private static final String DB_URL = "jdbc:postgresql://deprem.ccd6u6noakod.us-east-1.rds.amazonaws.com:5432/deprem";
    private static final String DB_USERNAME = "baysal";
    private static final String DB_PASSWORD = "Baysal01.";

    private EditText adEditText;
    private EditText soyadEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText telefonEditText;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        adEditText = findViewById(R.id.adEditText);
        soyadEditText = findViewById(R.id.soyadEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        telefonEditText = findViewById(R.id.telefonEditText);
        registerButton = findViewById(R.id.registerButton);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ad = adEditText.getText().toString();
                String soyad = soyadEditText.getText().toString();
                String kullaniciAdi = usernameEditText.getText().toString();
                String sifre = passwordEditText.getText().toString();
                String telefonNumarasi = telefonEditText.getText().toString();

                new RegisterUserTask().execute(ad, soyad, kullaniciAdi, sifre, telefonNumarasi);
            }
        });
    }

    private class RegisterUserTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            String ad = params[0];
            String soyad = params[1];
            String kullaniciAdi = params[2];
            String sifre = params[3];
            String telefonNumarasi = params[4];

            try {
                Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                String query = "INSERT INTO uyeler (ad, soyad, kullanici_adi, sifre, telefon_numarasi) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement statement = conn.prepareStatement(query);
                statement.setString(1, ad);
                statement.setString(2, soyad);
                statement.setString(3, kullaniciAdi);
                statement.setString(4, sifre);
                statement.setString(5, telefonNumarasi);
                statement.executeUpdate();
                statement.close();
                conn.close();
            } catch (SQLException e) {
                Log.e("RegisterActivity", "Error: " + e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // Kayıt işlemi sonrası için açtık
            Toast.makeText(RegisterActivity.this, "Kayıt işlemi başarıyla tamamlandı.", Toast.LENGTH_SHORT).show();

        }
    }
}
