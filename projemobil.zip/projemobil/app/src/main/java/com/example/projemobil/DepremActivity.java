package com.example.projemobil;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

public class DepremActivity extends AppCompatActivity {

    private TextView txtVeriler;
    private Button btnGuncelle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deprem);

        txtVeriler = findViewById(R.id.txtVeriler);
        btnGuncelle = findViewById(R.id.btnGuncelle);

        btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                VerileriGuncelleTask task = new VerileriGuncelleTask();
                task.execute();
            }
        });
    }

    private class VerileriGuncelleTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Verileri çekmek için kullanacağımız web sitesinin URL'si
                String url = "http://www.koeri.boun.edu.tr/scripts/lst9.asp";

                // URL'yi aç ve HTML içeriğini al
                InputStream inputStream = getInputStreamFromUrl(url);

                // HTML içeriğini Jsoup ile parse et
                org.jsoup.nodes.Document document = Jsoup.parse(inputStream, null, url);

                // XPath ifadesini kullanarak verileri seç
                String xpathExpression = "/html/body/pre/text()";
                String veriler = evaluateXPathExpression(document, xpathExpression);

                // Kısıtlamaları uygula
                veriler = applyRestrictions(veriler);

                return veriler;
            } catch (IOException | XPathExpressionException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String veriler) {
            if (veriler != null) {
                // Alınan verileri TextView'e yazdır
                txtVeriler.setText(veriler);
            } else {
                // Hata durumunda kullanıcıya bildirim gösterebilirsiniz
                // Örneğin:
                // Toast.makeText(DepremActivity.this, "Veriler alınamadı", Toast.LENGTH_SHORT).show();
            }
        }

        private InputStream getInputStreamFromUrl(String urlString) throws IOException {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            return connection.getInputStream();
        }

        private String evaluateXPathExpression(org.jsoup.nodes.Document document, String xpathExpression) throws XPathExpressionException {
            XPathFactory xPathFactory = XPathFactory.newInstance();
            XPath xPath = xPathFactory.newXPath();
            XPathExpression expression = xPath.compile(xpathExpression);

            // Jsoup belgesini W3C DOM belgesine dönüştür
            org.w3c.dom.Document w3cDocument = new org.jsoup.helper.W3CDom().fromJsoup(document);

            // XPath ifadesini W3C DOM belgesinde değerlendir
            return (String) expression.evaluate(w3cDocument, XPathConstants.STRING);
        }

        private String applyRestrictions(String veriler) {
            // - işaretini ve xy.abcd formatındaki verileri kaldır
            veriler = veriler.replaceAll("\\bxy\\.abcd\\b", "");

            // Enlem ve boylam verilerini kaldır
            veriler = removeLatitudeLongitude(veriler);

            // İstenmeyen boşlukları temizle
            veriler = veriler.trim().replaceAll("\\s+", " ");

            veriler = veriler.replace("..................TÜRKİYE VE YAKIN ÇEVRESİNDEKİ SON DEPREMLER....................", "")
                    .replace(".....BÖLGESEL DEPREM-TSUNAMİ İZLEME VE DEĞERLENDİRME MERKEZİ HIZLI ÇÖZÜMLERİ.....", "")
                    .replace("......(YAPAY SARSINTI ANALİZİ YAPILMAMIŞTIR) Son 500 deprem listelenmiştir......", "")
                    .trim();


            return veriler;
        }

        private String removeLatitudeLongitude(String veriler) {
            // Enlem ve boylam verilerini kaldırmak için regex kullan
            Pattern pattern = Pattern.compile("\\b\\d+\\.\\d+\\s+\\d+\\.\\d+\\b");
            Matcher matcher = pattern.matcher(veriler);
            return matcher.replaceAll("");

        }

        private String removeMultipleHyphens(String veriler) {
            // Yan yana 2'den fazla tire işaretini kaldırmak için regex kullan
            veriler = veriler.replaceAll("-{2,}", "");
            return veriler;
        }


    }
}
