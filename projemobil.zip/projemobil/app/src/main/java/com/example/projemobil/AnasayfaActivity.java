package com.example.projemobil;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AnasayfaActivity extends AppCompatActivity {

    private Button evdeYapilanlarButton;
    private Button aracdaYapilanlarButton;
    private Button depremGuvenlikIpuclariButton;
    private Button depremTatbikatButton;
    private Button bagisYapButton; // Yeni eklenen buton
    private Button depremCantasiButton;
    private Button btnSonDepremler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anasayfa);
        btnSonDepremler = findViewById(R.id.btnSonDepremler);

        evdeYapilanlarButton = findViewById(R.id.evdeYapilanlarButton);
        aracdaYapilanlarButton = findViewById(R.id.aracdaYapilanlarButton);
        depremGuvenlikIpuclariButton = findViewById(R.id.depremGuvenlikIpuclariButton);
        depremTatbikatButton = findViewById(R.id.depremTatbikatButton);
        bagisYapButton = findViewById(R.id.bagisYapButton); // Butonun tanımlanması
        depremCantasiButton = findViewById(R.id.depremCantasiButton);
        evdeYapilanlarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnasayfaActivity.this, DepremGuvenlikIpuclariActivity.class);
                startActivity(intent);
            }
        });

        btnSonDepremler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AnasayfaActivity.this, DepremActivity.class);
                startActivity(intent);
            }
        });

        aracdaYapilanlarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnasayfaActivity.this, DepremGuvenlikIpuclariActivity.class);
                startActivity(intent);
            }
        });

        depremCantasiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int userId = getIntent().getIntExtra("user_id", -1);  // Kullanıcının ID'sini al
                Intent intent = new Intent(AnasayfaActivity.this, DepremCantasiHazirlamaActivity.class);
                intent.putExtra("user_id", userId);  // Kullanıcının ID'sini DepremCantasiHazirlamaActivity'e aktar
                startActivity(intent);
            }
        });

        depremGuvenlikIpuclariButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnasayfaActivity.this, DepremGuvenlikIpuclariActivity.class);
                startActivity(intent);
            }
        });

        depremTatbikatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnasayfaActivity.this, DepremTatbikatAlarmiActivity.class);
                startActivity(intent);
            }
        });

        bagisYapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AnasayfaActivity.this, BagisActivity.class);
                startActivity(intent);
            }
        });
    }
}

